print('min')
