program PLineOA1;

uses
  Vcl.Forms,
  ULineOA1 in 'ULineOA1.pas' {Form7};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm7, Form7);
  Application.Run;
end.
